//
//  ViewController.swift
//  SegmentedControlDemo
//
//  Created by gdcp on 2018/3/14.
//  Copyright © 2018年 gdcp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let seg = UISegmentedControl(items: ["one","two","three","four"])
        
        seg.frame  = CGRect(x: 50, y: 100, width: 250, height: 40)
        //编码实现对其中的分段进行增删改的操作
        seg.insertSegment(withTitle: "zero", at: 0, animated: true)
        seg.removeSegment(at: 2, animated: false)
        seg.setTitle("0", forSegmentAt: 0)
        
        seg.addTarget(self, action: #selector(changeValue(seg:)), for: .valueChanged)
        
        self.view.addSubview(seg)
    }
    
    func changeValue(seg:UISegmentedControl){
        print(seg.selectedSegmentIndex)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

