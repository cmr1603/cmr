//
//  ViewController.swift
//  SearchBarDemo
//
//  Created by gdcp on 2018/3/22.
//  Copyright © 2018年 gdcp. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UISearchBarDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let searchBar = UISearchBar()
        
        searchBar.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: 44)
        searchBar.placeholder = "请输入搜索关键字"
        searchBar.tintColor = UIColor.red
        searchBar.showsSearchResultsButton = true
        searchBar.showsCancelButton = true
        
        searchBar.showsScopeBar = true
        searchBar.scopeButtonTitles = ["时事热点","娱乐热点"]
        /*
            处理用户搜索的业务逻辑
            (1)所在的控制器类，遵循协议UISearchBarDelegate
            (2)设置代理对象为当前的控制器实例
            (3)实现协议方法
         */
        searchBar.delegate = self
        
        self.view.addSubview(searchBar)
    }
    
    //单击搜索按钮时触发
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar){
        print(searchBar.text ?? "没有搜索内容")  //打印搜索文本
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

