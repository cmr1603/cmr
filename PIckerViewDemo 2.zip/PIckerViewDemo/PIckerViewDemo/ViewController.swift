//
//  ViewController.swift
//  PIckerViewDemo
//
//  Created by gdcp on 2018/3/21.
//  Copyright © 2018年 gdcp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDataSource,UIPickerViewDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pickerview = UIPickerView()
        pickerview.frame = CGRect(x:0,y:100,width:self.view.bounds.size.width,height:100)
        
        pickerview.dataSource = self
        pickerview.delegate = self
        
        self.view.addSubview(pickerview)
    
    }
    //返回(设置)列数
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 2
    }
    
    // 返回（设置）行数
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        //当两列的行数一样时
        //return 10
        //当两列的行数不一样时
        if(component == 0){
        return 5
        }else{
        return 10
        }
    }
    
    //设置要显示的文本
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "第\(component)列\(row)行"
    }
    
    //设置行高
    public func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 40
    }

}

