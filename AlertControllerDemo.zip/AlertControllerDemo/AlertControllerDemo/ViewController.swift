//
//  ViewController.swift
//  AlertControllerDemo
//
//  Created by gdcp on 2018/3/21.
//  Copyright © 2018年 gdcp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //触摸手机屏幕触发
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //1、创建警告控制器实例
        let alert = UIAlertController(title: "警告", message: "消息内容", preferredStyle: UIAlertControllerStyle.alert)
        //2、添加动作按钮(封装了相应操作的方法)
        let action = UIAlertAction(title: "确定", style: .default) { (UIAlertAction) in
            print("单击确定按钮")
        }
        let action2 = UIAlertAction(title: "取消", style: .cancel) { (UIAlertAction) in
            print("单击取消按钮")
        }
        //3、将动作按钮添加到控制器实例中
        alert.addAction(action)
        alert.addAction(action2)
        //4、显示警告控制器
        //self.view.addSubview(alert)  用法错误，因为alert是控制器实例，不是视图实例
        //以模式框方式显示控制器实例
        self.present(alert, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

