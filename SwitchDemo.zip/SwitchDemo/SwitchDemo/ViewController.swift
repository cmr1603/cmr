//
//  ViewController.swift
//  SwitchDemo
//
//  Created by gdcp on 2018/3/14.
//  Copyright © 2018年 gdcp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //1、创建控件实例
        let swi = UISwitch()
        //2、设置控件实例的属性
        swi.frame = CGRect(x: 100, y: 100, width: 80, height: 30)
        //swi.onTintColor = UIColor.green
        //swi.tintColor = UIColor.black
        //swi.thumbTintColor = UIColor.blue
        
        swi.addTarget(self, action: #selector(changeColor(swi:)), for: .touchUpInside)
        
        //3、添加到父视图中
        self.view.addSubview(swi)
    }

    func changeColor(swi:UISwitch){  //带当前的控件实例
        if swi.isOn {  //判断开启按钮是否处于开启状态
            self.view.backgroundColor = UIColor.red
        } else {
            self.view.backgroundColor = UIColor.gray
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

