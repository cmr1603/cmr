//
//  ViewController.swift
//  PageControlDemo
//
//  Created by gdcp on 2018/3/14.
//  Copyright © 2018年 gdcp. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black
        
        let page = UIPageControl()
        
        page.frame = CGRect(x: 100, y: 100, width: 100, height: 30)
        page.numberOfPages = 4  //页的数量
        page.currentPageIndicatorTintColor = UIColor.white
        
        page.addTarget(self, action: #selector(changeValue(page:)), for: .valueChanged)
        
        self.view.addSubview(page)
        
    }
    
    func changeValue(page:UIPageControl){
        print(page.currentPage)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

